<?php

return [
    'next'     => 'التالي &raquo;',
    'previous' => '&laquo; السابق',
];
