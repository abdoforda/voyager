@extends('app')
@section('title'){{ $page->title }}@endsection
@section('content')
    <!--START HEADER   SECTION-->
    <section class="about-us section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section">
                        <h3> {{ $page->title }} </h3>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="{{ asset('storage/'.$page->image) }}" alt="">
                </div>
                <div class="col-md-6">
                    <div class="about-text start">
                        {!! $page->body !!}
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="team section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section">
                        <h3>شركاء النجاح</h3>
                    </div>

                </div>
                <div class="our-team">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="team-num">
                                <img src="assets/img/jpg/team_img1.jpg" alt="">
                                <div class="team-title">
                                    <h4>محمد طلال رضا</h4>
                                    <h6>مدرب تنميه بشرية</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team-num">
                                <img src="assets/img/jpg/team_img2.jpg" alt="">
                                <div class="team-title">
                                    <h4>محمد طلال رضا</h4>
                                    <h6>مدرب تنميه بشرية</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team-num">
                                <img src="assets/img/jpg/team_img3.jpg" alt="">
                                <div class="team-title">
                                    <h4>محمد طلال رضا</h4>
                                    <h6>مدرب تنميه بشرية</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team-num">
                                <img src="assets/img/jpg/team_img4.jpg" alt="">
                                <div class="team-title">
                                    <h4>محمد طلال رضا</h4>
                                    <h6>مدرب تنميه بشرية</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
@endsection