@extends('app')
@section('title')سلة المشتريات@endsection
@section('content')
<!--START login  SECTION-->
<section class="login00 section gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-center">
                    <img src="{{ asset('assets/img/error.png') }}" style="width: 200px; opacity: 0.1" />
                    <br><br>
                    <h3>
                        هذه الصفحة غير موجودة
                    </h3>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection