@extends('layouts.app')

@section('content')
<video src="http://localhost/laravel/businessgate/public/storage/products/May2021/uFi0uzqz4jq5bBHT5B9S.mp4" controls width="300px" />
@endsection
