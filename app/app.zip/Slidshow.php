<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slidshow extends Model
{
    //
}
