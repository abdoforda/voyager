<?php

namespace App;

use App\Scopes\ActiveCoach;
use Illuminate\Database\Eloquent\Model;

class Coach extends Model
{

    protected $table = 'coaches';

    

}
