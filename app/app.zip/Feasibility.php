<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Feasibility extends Model
{
    protected $table = 'feasibilitys';
}
